

```python
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
```


```python
rideData = pd.read_csv("ride_data.csv")
rideData.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Sarabury</td>
      <td>2016-01-16 13:49:27</td>
      <td>38.35</td>
      <td>5403689035038</td>
    </tr>
    <tr>
      <th>1</th>
      <td>South Roy</td>
      <td>2016-01-02 18:42:34</td>
      <td>17.49</td>
      <td>4036272335942</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Wiseborough</td>
      <td>2016-01-21 17:35:29</td>
      <td>44.18</td>
      <td>3645042422587</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Spencertown</td>
      <td>2016-07-31 14:53:22</td>
      <td>6.87</td>
      <td>2242596575892</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Nguyenbury</td>
      <td>2016-07-09 04:42:44</td>
      <td>6.28</td>
      <td>1543057793673</td>
    </tr>
  </tbody>
</table>
</div>




```python
rideData_clean = rideData.drop_duplicates('ride_id')
```


```python
cityData = pd.read_csv("city_data.csv")
cityData.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Nguyenbury</td>
      <td>8</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>2</th>
      <td>East Douglas</td>
      <td>12</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>3</th>
      <td>West Dawnfurt</td>
      <td>34</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Rodriguezburgh</td>
      <td>52</td>
      <td>Urban</td>
    </tr>
  </tbody>
</table>
</div>




```python
pyber_df = pd.merge(cityData, rideData_clean, on="city")
pyber_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>type</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-08-19 04:27:52</td>
      <td>5.51</td>
      <td>6246006544795</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-04-17 06:59:50</td>
      <td>5.54</td>
      <td>7466473222333</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-05-04 15:06:07</td>
      <td>30.54</td>
      <td>2140501382736</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-01-25 20:44:56</td>
      <td>12.08</td>
      <td>1896987891309</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-08-09 18:19:47</td>
      <td>17.91</td>
      <td>8784212854829</td>
    </tr>
  </tbody>
</table>
</div>




```python
#dataPoints = len(rideData['ride_id'].unique())

#fares_by_city = pyber_df.groupby('city')['fare'].sum()
#rides_by_city = pyber_df.groupby('city')['fare'].count()
#avg_by_city = round(pyber_df.groupby('city')['fare'].mean(),2)
#driver_by_city = pyber_df.groupby('city')['driver_count'].max()

#Ride_Analysis = pd.DataFrame(
#    {
#        "Total Fares": fares_by_city,
#        "Total Rides": rides_by_city,
#        "Average Fare": avg_by_city,
#        "Number of Drivers": driver_by_city,
#        "City Type": city_type
#    })

#Ride_Analysis_Sorted = Ride_Analysis.sort_values("Total Fares", ascending = False)

#Ride_Analysis_Sorted

#Ride_Analysis
```


```python
#df.plot.scatter(x='a', y='b', s=df['c']*200)
    
# Tell matplotlib to create a scatter plot based upon the above data
#plt.scatter(temp, sales, marker="o", facecolors="red", edgecolors="black")

# Set the upper and lower limits of our y axis
#plt.ylim(180,620)

# Set the upper and lower limits of our x axis
#plt.xlim(11,26)

# Create a title, x label, and y label for our chart
#plt.title("Ice Cream Sales v Temperature")
#plt.xlabel("Temperature (Celsius)")
#plt.ylabel("Sales (Dollars)")

# Save an image of the chart and print to screen
#plt.savefig("../Images/IceCreamSales.png")
#plt.show()

```


```python
Urban = pyber_df.loc[pyber_df['type'] == 'Urban']
Suburban = pyber_df.loc[pyber_df['type'] == 'Suburban']
Rural = pyber_df.loc[pyber_df['type'] == 'Rural']

URBAN_fares_by_city = Urban.groupby('city')['fare'].sum()
URBAN_rides_by_city = Urban.groupby('city')['fare'].count()
URBAN_avg_by_city = round(Urban.groupby('city')['fare'].mean(),2)
URBAN_driver_by_city = Urban.groupby('city')['driver_count'].max()

URBAN_Ride_Analysis = pd.DataFrame(
    {
        "Total Fares": URBAN_fares_by_city,
        "Total Rides": URBAN_rides_by_city,
        "Average Fare": URBAN_avg_by_city,
        "Number of Drivers": URBAN_driver_by_city,
    })

URBAN_Ride_Analysis_Sorted = URBAN_Ride_Analysis.sort_values("Total Fares", ascending = False)

SUBURBAN_fares_by_city = Suburban.groupby('city')['fare'].sum()
SUBURBAN_rides_by_city = Suburban.groupby('city')['fare'].count()
SUBURBAN_avg_by_city = round(Suburban.groupby('city')['fare'].mean(),2)
SUBURBAN_driver_by_city = Suburban.groupby('city')['driver_count'].max()

SUBURBAN_Ride_Analysis = pd.DataFrame(
    {
        "Total Fares": SUBURBAN_fares_by_city,
        "Total Rides": SUBURBAN_rides_by_city,
        "Average Fare": SUBURBAN_avg_by_city,
        "Number of Drivers": SUBURBAN_driver_by_city,
    })

SUBURBAN_Ride_Analysis_Sorted = SUBURBAN_Ride_Analysis.sort_values("Total Fares", ascending = False)

RURAL_fares_by_city = Rural.groupby('city')['fare'].sum()
RURAL_rides_by_city = Rural.groupby('city')['fare'].count()
RURAL_avg_by_city = round(Rural.groupby('city')['fare'].mean(),2)
RURAL_driver_by_city = Rural.groupby('city')['driver_count'].max()

RURAL_Ride_Analysis = pd.DataFrame(
    {
        "Total Fares": RURAL_fares_by_city,
        "Total Rides": RURAL_rides_by_city,
        "Average Fare": RURAL_avg_by_city,
        "Number of Drivers": RURAL_driver_by_city,
    })

RURAL_Ride_Analysis_Sorted = RURAL_Ride_Analysis.sort_values("Total Fares", ascending = False)




URBAN_Ride_Analysis_Sorted.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Average Fare</th>
      <th>Number of Drivers</th>
      <th>Total Fares</th>
      <th>Total Rides</th>
    </tr>
    <tr>
      <th>city</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Swansonbury</th>
      <td>27.46</td>
      <td>64</td>
      <td>933.80</td>
      <td>34</td>
    </tr>
    <tr>
      <th>Port Johnstad</th>
      <td>25.88</td>
      <td>22</td>
      <td>880.02</td>
      <td>34</td>
    </tr>
    <tr>
      <th>South Louis</th>
      <td>27.09</td>
      <td>12</td>
      <td>866.80</td>
      <td>32</td>
    </tr>
    <tr>
      <th>Williamshire</th>
      <td>26.99</td>
      <td>70</td>
      <td>836.70</td>
      <td>31</td>
    </tr>
    <tr>
      <th>Lisaville</th>
      <td>28.43</td>
      <td>66</td>
      <td>796.01</td>
      <td>28</td>
    </tr>
  </tbody>
</table>
</div>




```python
SUBURBAN_Ride_Analysis_Sorted.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Average Fare</th>
      <th>Number of Drivers</th>
      <th>Total Fares</th>
      <th>Total Rides</th>
    </tr>
    <tr>
      <th>city</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Port James</th>
      <td>31.81</td>
      <td>15</td>
      <td>2035.62</td>
      <td>64</td>
    </tr>
    <tr>
      <th>New Samanthaside</th>
      <td>34.07</td>
      <td>16</td>
      <td>783.59</td>
      <td>23</td>
    </tr>
    <tr>
      <th>Thomastown</th>
      <td>30.31</td>
      <td>1</td>
      <td>727.40</td>
      <td>24</td>
    </tr>
    <tr>
      <th>Rodriguezview</th>
      <td>31.87</td>
      <td>10</td>
      <td>637.33</td>
      <td>20</td>
    </tr>
    <tr>
      <th>East Jenniferchester</th>
      <td>32.60</td>
      <td>22</td>
      <td>619.39</td>
      <td>19</td>
    </tr>
  </tbody>
</table>
</div>




```python
RURAL_Ride_Analysis_Sorted.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Average Fare</th>
      <th>Number of Drivers</th>
      <th>Total Fares</th>
      <th>Total Rides</th>
    </tr>
    <tr>
      <th>city</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>South Joseph</th>
      <td>38.98</td>
      <td>3</td>
      <td>467.80</td>
      <td>12</td>
    </tr>
    <tr>
      <th>East Stephen</th>
      <td>39.05</td>
      <td>6</td>
      <td>390.53</td>
      <td>10</td>
    </tr>
    <tr>
      <th>North Whitney</th>
      <td>38.15</td>
      <td>10</td>
      <td>381.46</td>
      <td>10</td>
    </tr>
    <tr>
      <th>East Leslie</th>
      <td>33.66</td>
      <td>9</td>
      <td>370.27</td>
      <td>11</td>
    </tr>
    <tr>
      <th>Kennethburgh</th>
      <td>36.93</td>
      <td>3</td>
      <td>369.28</td>
      <td>10</td>
    </tr>
  </tbody>
</table>
</div>




```python
uride = URBAN_Ride_Analysis['Total Rides']
ufare = URBAN_Ride_Analysis['Average Fare']
udrive = URBAN_Ride_Analysis['Number of Drivers']

suride = SUBURBAN_Ride_Analysis['Total Rides']
sufare = SUBURBAN_Ride_Analysis['Average Fare']
sudrive = SUBURBAN_Ride_Analysis['Number of Drivers']

ruride = RURAL_Ride_Analysis['Total Rides']
rufare = RURAL_Ride_Analysis['Average Fare']
rudrive = RURAL_Ride_Analysis['Number of Drivers']
```


```python
#URBAN_Ride_Analysis_Sorted.plot.scatter('Total Rides','Average Fare', s = URBAN_Ride_Analysis['Number of Drivers'],
#                           c = ['gold'], edgecolors = "black")
#SUBURBAN_Ride_Analysis_Sorted.plot.scatter('Total Rides','Average Fare', s = SUBURBAN_Ride_Analysis['Number of Drivers'],
#                           c = ['blue'], edgecolors = "black")
#RURAL_Ride_Analysis_Sorted.plot.scatter('Total Rides','Average Fare', s = RURAL_Ride_Analysis['Number of Drivers'],
#                           c = ['coral'], edgecolors = "black")

plt.scatter(uride, ufare, s = udrive, c = ['coral'], alpha = 0.7, linewidths = 0.3, edgecolors="black", label = "Urban")   
plt.scatter(suride, sufare, s = sudrive, c = ['lightblue'], alpha = 0.7, linewidths = 0.3, edgecolors="black", label = "Suburban")
plt.scatter(ruride, rufare, s = rudrive, c = ['gold'], alpha = 0.7,  linewidths = 0.3, edgecolors="black", label = "Rural")

plt.ylim(18,40)
plt.xlim(4,35)

plt.title("Pyber Ride Sharing Data (2016)")
plt.xlabel("Total Rides")
plt.ylabel("Average Fare")
plt.grid()
plt.legend(loc = "best")

# c = ['gold', 'light sky blue', 'light coral']
#Axes.scatter(x, y, s=None, c=None, marker=None, cmap=None, norm=None, vmin=None,
#             vmax=None, alpha=None, linewidths=None, verts=None, edgecolors=None, *,
#             data=None, **kwargs)


plt.show()
```


![png](output_11_0.png)



```python
#% of Total Fares by City Type
#% of Total Rides by City Type
#% of Total Drivers by City Type

total_fares = pyber_df.groupby('type')['fare'].sum()
total_rides = pyber_df.groupby('type')['fare'].count()
total_drivers = pyber_df.groupby('type')['driver_count'].max()

faresCount = pyber_df['fare'].count()
faresSum = pyber_df['fare'].sum()
driverSum = cityData['driver_count'].sum()

PercentAnalysis = pd.DataFrame(
    {
        "Total Fares": total_fares,
        "% Fare of Total": round((total_fares/faresSum)*100,2),
        "Total Rides": total_rides,
        "% Rides of Total": round((total_rides/faresCount)*100,2),
        "Total Drivers": total_drivers,
        "% Drivers of Total": round((total_drivers/driverSum)*100,2)
    })

PercentAnalysis
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>% Drivers of Total</th>
      <th>% Fare of Total</th>
      <th>% Rides of Total</th>
      <th>Total Drivers</th>
      <th>Total Fares</th>
      <th>Total Rides</th>
    </tr>
    <tr>
      <th>type</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Rural</th>
      <td>0.30</td>
      <td>6.58</td>
      <td>5.19</td>
      <td>10</td>
      <td>4255.09</td>
      <td>125</td>
    </tr>
    <tr>
      <th>Suburban</th>
      <td>0.81</td>
      <td>31.45</td>
      <td>27.30</td>
      <td>27</td>
      <td>20335.69</td>
      <td>657</td>
    </tr>
    <tr>
      <th>Urban</th>
      <td>2.18</td>
      <td>61.97</td>
      <td>67.51</td>
      <td>73</td>
      <td>40078.34</td>
      <td>1625</td>
    </tr>
  </tbody>
</table>
</div>




```python
perRide = PercentAnalysis['% Rides of Total']
perFare = PercentAnalysis['% Fare of Total']
perDrive = PercentAnalysis['% Drivers of Total']
perType = ["Rural","Suburban","Urban"]

#plt.pie(sizes, explode=explode, labels=labels, colors=colors,
#        autopct="%1.1f%%", shadow=True, startangle=140)

plt.pie(perDrive, labels = perType)

```




    ([<matplotlib.patches.Wedge at 0x24734742c18>,
      <matplotlib.patches.Wedge at 0x2473474c128>,
      <matplotlib.patches.Wedge at 0x2473474c668>],
     [Text(1.05517,0.310822,'Rural'),
      Text(0.244773,1.07242,'Suburban'),
      Text(-0.537827,-0.959553,'Urban')])




![png](output_13_1.png)

